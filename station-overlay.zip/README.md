# CityRoute sparse GTFS overlay and station geometry format

This document defines `cityroute.gtfs-overlay/v1` and
`cityroute.station-geometry/v1`.

## Overlay ZIP

An exported ZIP can contain:

```text
overlay_manifest.json
stops.txt                 # only when at least one stop row changed or was added
levels.txt                # only when at least one level row changed or was added
pathways.txt              # only when at least one pathway row changed or was added
translations.txt          # only when a customer-facing GTFS value was translated
station_geometry.geojson
README.md
```

The text files are standard comma-separated GTFS files. There are no subdirectories.

### Merge semantics

The imported TPBI feed is the immutable base. Each overlay text file contains **complete rows**, not
field-level patches:

1. Match `stops.txt` on `stop_id`, `levels.txt` on `level_id`, and `pathways.txt` on `pathway_id`.
   Match `translations.txt` on its standard composite primary key:
   `table_name`, `field_name`, `language`, `record_id`, `record_sub_id`, and `field_value`.
2. If an overlay primary key exists in TPBI, replace that complete TPBI row.
3. If an overlay primary key is new, append the row.
4. TPBI rows omitted from the overlay remain unchanged.
5. Overlay v1 has no deletion operation.

Do not treat an overlay ZIP as a standalone GTFS feed. A consumer must first verify the source
fingerprint in `overlay_manifest.json`, then apply the sparse upserts to a compatible TPBI base.

`overlay_manifest.json` records:

- schema and creation time;
- source ZIP name, URL (when known), SHA-256, and feed version;
- included tables, primary keys, and row counts;
- explicit merge behaviour;
- the geometry file and feature count.

An edited standard row retains columns found in the imported source. The exporter also includes
all fields known by the editor, so TPBI-specific or future columns are not silently discarded.

### Node-title translations

Translated node titles are standard record-based `translations.txt` rows targeting
`table_name=stops` and `field_name=stop_name`. The node's `stop_id` is stored in `record_id`;
`record_sub_id` and `field_value` remain empty. `language` is a BCP 47 language code such as `en`,
`de`, or `en-GB`. The original `stops.stop_name` remains the Romanian/default-language value.

```csv
table_name,field_name,language,translation,record_id,record_sub_id,field_value
stops,stop_name,en,Street-level entrance,CR_EXAMPLE_ENTRANCE,,
```

## `station_geometry.geojson`

The file is an RFC 7946 GeoJSON `FeatureCollection`. Coordinates use longitude, latitude axis order
in `OGC:CRS84` (WGS 84 decimal degrees). No height coordinate is required; `level_id` carries the
station's semantic vertical level.

Top-level envelope:

```json
{
  "type": "FeatureCollection",
  "properties": {
    "schema": "cityroute.station-geometry/v1",
    "crs": "OGC:CRS84",
    "source_gtfs_sha256": "…"
  },
  "features": []
}
```

Every feature has:

| Property | Required | Meaning |
| --- | --- | --- |
| `feature_id` | yes | Globally unique, stable identifier. |
| `feature_type` | yes | One of the types below. |
| `station_id` | yes | Parent station `stop_id` in the effective GTFS feed. |
| `level_id` | usually | `level_id` in the effective GTFS feed; empty is allowed for a whole-station boundary. |
| `name` | no | Human-readable feature name. |
| `source` | recommended | Provenance such as `operator_plan`, `field_survey`, or `manual_survey`. |
| `notes` | no | Free-form survey or modelling note. |
| `fill_opacity` | no | Polygon display opacity from `0` (transparent) through `1` (opaque); editor-only and ignored by routing. |

### Feature types

#### `station_boundary` · Polygon

An approximate station complex footprint. It may include multiple underground levels; leave
`level_id` empty when it does. Its required `station_id` links it to the parent-station row and
implicitly includes that station plus every current or future GTFS stop whose `parent_station`
points to it. Do not add a `gtfs_stop_id` for each child: a station boundary is station-wide, not a
single-stop geometry.

#### `level_area` · Polygon

The known navigable or surveyed extent of one `level_id`. This is not automatically a walkable
polygon and must not be used as routing topology by itself.

#### `platform_area` · Polygon

The physical passenger platform surface.

Additional properties:

| Property | Values / meaning |
| --- | --- |
| `gtfs_stop_id` | Primary GTFS platform/boarding stop represented by the polygon. |
| `serves_stop_ids` | Array of every GTFS stop/boarding area served by the surface. |
| `platform_kind` | `side`, `island`, `other`, or `unknown`. `island` means tracks border two sides. |
| `shared_platform` | `yes`, `no`, or `unknown`. Kept separate because an island platform may or may not be shared by multiple services or directions. |
| `rail_side` | `left`, `right`, `both`, `center`, or `unknown`, recorded as platform metadata relative to the local survey convention. |
| `track_refs` | Array of operator or survey track labels. |

Example:

```json
{
  "type": "Feature",
  "properties": {
    "feature_id": "CR_PIATA_UNIRII_1_PLATFORM_1",
    "feature_type": "platform_area",
    "station_id": "SOURCE_PARENT_STATION_ID",
    "level_id": "CR_PIATA_UNIRII_1_L_MINUS_2",
    "gtfs_stop_id": "SOURCE_PLATFORM_1",
    "serves_stop_ids": ["SOURCE_PLATFORM_1", "SOURCE_PLATFORM_2"],
    "platform_kind": "island",
    "shared_platform": "yes",
    "rail_side": "both",
    "track_refs": ["1", "2"],
    "source": "operator_plan"
  },
  "geometry": {
    "type": "Polygon",
    "coordinates": [[[26.101, 44.427], [26.102, 44.427], [26.102, 44.426], [26.101, 44.427]]]
  }
}
```

#### `platform_node` · Point

Operational metadata owned by one GTFS platform or boarding node, rather than by a shared platform
polygon. The point coordinates mirror the linked GTFS stop and move with it.

| Property | Values / meaning |
| --- | --- |
| `gtfs_stop_id` | Required platform (`location_type=0`) or boarding-area (`location_type=4`) stop. |
| `door_side` | `left`, `right`, `both`, or `unknown`, from inside the arriving train while facing its direction of travel. |

```json
{
  "type": "Feature",
  "properties": {
    "feature_id": "CR_PIATA_UNIRII_1_PLATFORM_NODE_1",
    "feature_type": "platform_node",
    "station_id": "SOURCE_PARENT_STATION_ID",
    "level_id": "CR_PIATA_UNIRII_1_L_MINUS_2",
    "gtfs_stop_id": "SOURCE_PLATFORM_1",
    "door_side": "right",
    "source": "operator_plan"
  },
  "geometry": {
    "type": "Point",
    "coordinates": [26.101, 44.427]
  }
}
```

#### `pathway_geometry` · LineString

The physical horizontal trace of one standard GTFS Pathways edge.

Additional properties:

| Property | Meaning |
| --- | --- |
| `gtfs_pathway_id` | `pathway_id` in the effective GTFS feed. |
| `measured_length_m` | Geodesic length calculated from the line; informational and copied to GTFS `length` when first drawn. |

The line gives the pathway a map dimension but does not replace `from_stop_id`, `to_stop_id`,
`pathway_mode`, directionality, traversal time, accessibility, or signage in `pathways.txt`.
Multiple geometry features may reference the same pathway only when a consumer explicitly supports
segmented rendering; the normal model is one line per pathway.

### Traversal time

The editor is the only authority for `pathways.traversal_time`. It writes a value for **every**
overlay pathway mode, so a consumer never estimates one and a rider is always shown the same
number the surveyor saw in the route preview. On project/feed load, existing sparse-overlay
pathways are recalculated when a saved metric differs from the model below. Untouched source-feed
rows are not copied into the overlay.

Horizontal length drives only the modes a rider walks:

| Mode | Model |
| --- | --- |
| `1` walkway | traced length at 4 km/h |
| `2` stairs | traced length at 2 km/h |
| `3` moving sidewalk | traced length at 6 km/h (belt speed plus a walking contribution) |

Escalators and elevators are driven by the number of station levels they span, because their speed
is set by the machine rather than by the traced ground distance:

| Mode | Model |
| --- | --- |
| `4` escalator | 5 s to board and alight, plus 15.4 s per level spanned |
| `5` elevator | 60 s to call the car and hold the doors, plus 30 s per level spanned |
| `6` fare gate, `7` exit gate | a flat 10 s to produce a ticket and pass the barrier |

The escalator figure is `level rise ÷ sin(30°) ÷ 0.65 m/s`. A 30° inclination is the standard
transit geometry, 0.65 m/s is the EN 115 speed tier used for high-utilisation infrastructure rather
than the 0.5 m/s commercial tier, and one station level is taken as 5 m of rise — Bucharest's
first-generation stations are two-level cut-and-cover boxes with the platform at roughly 10 m.

Levels are resolved from the **merged** feed, because a station pathway routinely joins a TPBI
source level (`1` at street level, `0` at the mezzanine) to an overlay-authored platform level. An
escalator whose endpoints resolve to the same level, or whose level is unknown, has no rise to work
from and falls back to its traced run at escalator speed; that is usually a sign of a missing or
mis-set `level_id` rather than a real flat escalator.

#### Fare and exit gates

Fare gates are not custom GeoJSON feature types. They are standard GTFS Pathways edges:

- create a generic `stops.txt` node (`location_type=3`) on each side of the barrier;
- connect the unpaid-side and paid-side nodes with `pathways.txt pathway_mode=6`;
- use `pathway_mode=7` and `is_bidirectional=0` for an exit-only gate;
- represent the surveyed physical trace, when needed, with an ordinary `pathway_geometry`
  LineString linked through `gtfs_pathway_id`.

This two-node model preserves which side of the barrier a passenger occupies. A single “fare gate
point” is intentionally not part of the CityRoute geometry schema because it cannot represent the
paid/unpaid transition that GTFS routing needs.

#### `entrance_area` · Polygon

Optional physical footprint of an entrance structure. Link `gtfs_stop_id` to a standard GTFS
entrance/exit (`location_type=2`) when one exists.

## Relationship to standard GTFS

Standard GTFS fields remain authoritative for:

- station/node hierarchy (`location_type`, `parent_station`);
- node point coordinates (`stop_lat`, `stop_lon`);
- vertical ordering (`levels.txt`, `level_id`);
- pathway graph edges and traversal/accessibility data (`pathways.txt`);
- platform codes.

The GeoJSON extension is authoritative only for geometry GTFS cannot express:

- station, level, entrance, and platform polygons;
- a physical line for a pathway edge;
- platform operating metadata: track references and rail adjacency on the polygon, door side on
  each linked `platform_node`;
- island/shared platform semantics and track linkage.

Routing must still use the GTFS Pathways graph. Polygons do not create implicit edges, and line
intersections do not create implicit graph nodes.

## Identifier guidance

Keep TPBI identifiers when overriding TPBI rows. Prefix newly created identifiers with `CR_` and a
stable station slug. Never recycle an identifier for a different physical object.

## Validation

The editor blocks export when:

- an overlaid stop lacks `stop_name`;
- numeric stop coordinates are malformed;
- a stop references an unknown parent or level;
- a pathway endpoint does not exist in the effective feed;
- a pathway lacks `pathway_mode`;
- a geometry feature lacks an ID or station;
- a geometry link references an unknown GTFS stop or pathway.

Unknown geometry levels are warnings. Geometric self-intersection, indoor clearance, survey
accuracy, platform-track topology, and accessibility correctness require a separate QA process.
